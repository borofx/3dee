// Функция за зареждане на навигацията
function loadNavigation() {
    fetch('nav.html')
        .then(response => response.text())
        .then(data => {
            document.getElementById('navigation').innerHTML = data;
            
            // Вземи текущата страница
            const currentPage = window.location.pathname.split('/').pop();
            
            // Премахни активния клас от всички линкове
            document.querySelectorAll('.nav-links a').forEach(link => {
                link.classList.remove('active');
            });
            
            // Добави активен клас към текущата страница
            const activeLink = document.getElementById(`nav-${currentPage.replace('.html', '')}`);
            if (activeLink) {
                activeLink.classList.add('active');
            }
            
            // Актуализирай брояча на кошницата
            const cart = JSON.parse(localStorage.getItem('cart')) || [];
            const cartCount = document.getElementById('cart-count');
            if (cartCount) {
                cartCount.textContent = `(${cart.length})`;
            }
        })
        .catch(error => console.error('Error loading navigation:', error));
}

// Зареди навигацията при зареждане на страницата
document.addEventListener('DOMContentLoaded', loadNavigation); 